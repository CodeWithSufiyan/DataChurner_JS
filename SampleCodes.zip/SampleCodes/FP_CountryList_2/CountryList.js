﻿/**
 * Get CountryListNode for given data
 * @param {any} HTMLGeneratorClosure HTMLGenerator implementation
 * @param {any} CountryListJson Countrylist data
 */
function GetCountryListNode(HTMLGeneratorClosure, CountryListJson) {
	//Get container element from generator
	var eltContainer = HTMLGeneratorClosure.getContainerElement();
	eltContainer.classList.add('CountryListContainer');
	//Get list of CountryItems for each country in the data list
	var arrEltCountries = CountryListJson.CountryList.map(HTMLGeneratorClosure.getCountryElement);
	//Add every country element to container
	arrEltCountries.every(function (elt, index) {
		elt.classList.add('CountryItem')
		eltContainer.appendChild(elt);
		return true;
	});

	return eltContainer;
}

/**
 * Get CountryListNode for given data as an ordered lists
 * @param {any} CountryListJSON CountryList data
 */
function GetCountryListNode_impl_ol(CountryListJSON) {
	return GetCountryListNode(HTMLGeneratorClosure_impl_ol, CountryListJSON);
}

HTMLGeneratorClosure_impl_ol = {
	getContainerElement: function () {
		var eltContainer = document.createElement('ol');
		return eltContainer;
	},
	getCountryElement: function (country) {
		var eltCountry = document.createElement('li');
		eltCountry.innerHTML =
			'<a name="' + country.code + '">' +
			'<img src="famfamfam_flag_icons/png/' + country.code + '.png" />' + 
			country.name + '(' + country.code + ')' +
			'</a>';
		return eltCountry;
	}
};


/**
 * Get CountryListNode for given data as a linked tag cloud
 * @param {any} CountryListJSON CountryList data
 */
function GetCountryListNode_impl_tagcloud(CountryListJSON) {
	return GetCountryListNode(HTMLGeneratorClosure_impl_tagcloud, CountryListJSON);
}

HTMLGeneratorClosure_impl_tagcloud = {
	getContainerElement: function () {
		var eltContainer = document.createElement('div');
		return eltContainer;
	},
	getCountryElement: function (country) {
		var eltCountry = document.createElement('span');
		var width = randomIntInRange(32, 128);
		eltCountry.innerHTML =
			'<a href="#' + country.code + '" title="' + country.name + '">' +
			'<img src="famfamfam_flag_icons/png/' + country.code + '.png" width="' + width + '"/>' +
			'</a>';
	
		deg = randomIntInRange(-30, 30);
		eltCountry.style.webkitTransform = 'rotate('+deg+'deg)'; 
		eltCountry.style.mozTransform    = 'rotate('+deg+'deg)'; 
		eltCountry.style.msTransform     = 'rotate('+deg+'deg)'; 
		eltCountry.style.oTransform      = 'rotate('+deg+'deg)'; 
		eltCountry.style.transform       = 'rotate('+deg+'deg)'; 
		return eltCountry;
	}
};

/**
 * Generates a random integer within the given range
 * @param {any} min Minimum value of the random (inclusive)
 * @param {any} max Maximum value of the random (inclusives)
 */
function randomIntInRange(min, max) {
	var diff = min - max;
	var size = min + Math.round(Math.abs(diff * Math.random()));
	return size;
}

/**
 * Generates a random RGB color.
 * @param {any} fBright indicates whether to generate a dark shade or bright
 * @returns A random color. If fBright is true, all 3 color components (RGB) are between 128-255.
 */
function getRandomColor(fBright) {
	var color = '#';
	for (var i = 0; i < 3; i++) {
		var sPart = (fBright == true ? randomIntInRange(128, 255) : randomIntInRange(64, 128)).toString(16);
		if (sPart.length == 1) {
			sPart = "0" + sPart;
		}
		color += sPart;
	}
	return color;
}


function GetCountryListNode_impl_select(CountryListJSON) {
	return GetCountryListNode( //Defining an anonymous closure
		{
			getContainerElement: function () {
				var eltContainer = document.createElement('select');
				return eltContainer;
			},
			getCountryElement: function (country) {
				var eltCountry = document.createElement('option');
				eltCountry.innerHTML = country.name;
				eltCountry.value = country.code;
				eltCountry.style.backgroundImage = 'url("famfamfam_flag_icons/png/' + country.code + '.png")';
				return eltCountry;
			}
		},
		CountryListJSON
	);
}
