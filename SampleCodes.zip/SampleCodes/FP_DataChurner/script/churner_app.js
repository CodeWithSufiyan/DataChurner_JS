(function($){

    function fnGetUnitOperationSet(){
        return [
            {
                'sName': 'Unit',
                '__fDef': function(val){return val;}
            },
            {
                'sName': 'Square',
                '__fDef': function(val){return val*val;}
            },
            {
                'sName': 'Twice',
                '__fDef': function(val){return val*2;}
            },
            {
                'sName': 'NearestHundreds',
                '__fDef': function(val){return Math.round(val/100)*100;}
            }
        ];
    }

    function fnGetAggregationOperationSet(){
        return[
            {
                'sName': 'Sum',
                '__fDef': function(arrVal){
                    return arrVal.reduce(function(sum, val, index){
                        return sum + parseInt(val);
                    }, 0);
                }
            },
            {
                'sName': 'Average',
                '__fDef': function(arrVal){
                    return (arrVal.reduce(function(sum, val, index){
                        return sum + parseInt(val);
                    }, 0) / arrVal.length);
                }
            },
            {
                'sName': 'Count',
                '__fDef': function(arrVal){
                    return arrVal.length;
                }
            },
        ]
    }

    function fnCreateOperationOption(operation){
        return $('<option></option>')
        .val(operation.sName)
        .html(operation.sName)
        .data('__fDef', operation.__fDef);
    }
    function fnCreateOutputDataListItem(outputData){
        return $('<li></li>').html(outputData);
    }
    function fnCreateOutputDataList(arrOutputData){
        return $('<ul></ul>')
                .append(arrOutputData.map(fnCreateOutputDataListItem));
    }

    //Main application function
    function churnData(
        eltInputDataList,
        eltChoiceUnitOperation,
        eltChoiceAggragationOperation,
        eltOutputDataAggragate
    ){
        var arrInputData = eltInputDataList.val();
        var fnUnitOperation = eltChoiceUnitOperation
                                .children(':selected')
                                .data('__fDef');
        var arrOutputData = arrInputData.map(fnUnitOperation);
        var outputAggragationData = eltChoiceAggragationOperation
                                .find('option:selected')
                                .data('__fDef')(arrOutputData);
        eltOutputDataList.html(fnCreateOutputDataList(arrOutputData));
        eltOutputDataAggragate.html(
            eltChoiceAggragationOperation.val() + ': ' + outputAggragationData //outputDataAggragate
        );
    }


    var fnDataChurnerFunction = function(e){
        churnData(
            eltInputDataList,
            eltChoiceUnitOperation,
            eltChoiceAggragationOperation,
            eltOutputDataAggragate);
    };

    var eltInputDataList = $('#inputDataList');
    var eltChoiceUnitOperation = $('#choiceUnitOperation');
    var eltOutputDataList = $('#outputDataList');
    var eltChoiceAggragationOperation = $('#choiceAggragationOperation');
    var eltOutputDataAggragate = $('#outputDataAggragate');

    var arrUnitOperations = fnGetUnitOperationSet();
    var arrAggragationOperations = fnGetAggregationOperationSet();

    eltChoiceUnitOperation.append(
        arrUnitOperations.map(fnCreateOperationOption)
    );

    eltChoiceAggragationOperation.append(
        arrAggragationOperations.map(fnCreateOperationOption)
    );

    eltInputDataList.change(fnDataChurnerFunction);
    eltChoiceUnitOperation.change(fnDataChurnerFunction);
    eltChoiceAggragationOperation.change(fnDataChurnerFunction);

    for (var i = 0; i < 50; i++) {
        var nRandomInt = Math.round(Math.random()*1000);
        eltInputDataList.append(
            $('<option value="' + nRandomInt + '">' + nRandomInt + '</option>')
        );
    }
})(jQuery);
